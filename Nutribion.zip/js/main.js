window.addEventListener("DOMContentLoaded", function() {

	var allbtn = document.querySelectorAll(".review__more");

	[].forEach.call( allbtn, function (item) {
		item.addEventListener('click', function() {
			if (!item.parentNode.querySelector(".review__text").classList.contains("review__text_full")){
				item.parentNode.querySelector(".review__text").classList.add("review__text_full");
				item.classList.add("review__more_minus");
			}else{
				item.parentNode.querySelector(".review__text").classList.remove("review__text_full");
				item.classList.remove("review__more_minus");
			}
		});
	});

	String.prototype.removeSpaces = function() {
        return this.replace(/[^\d/]+/g, '');
    }

	document.querySelector(".code-input").addEventListener("input", function(event) {
		this.value = this.value.removeSpaces();
	});

	var flagCompare = true;
	var flagReview = true;
	var flagHowUse = true;

	window.addEventListener("scroll", function(e) {
		if (isVisible(document.querySelector(".why-title")) && flagCompare){
			flagCompare = false;
			var allIcon = document.querySelectorAll(".why__icon");

			[].forEach.call( allIcon, function (item) {
				item.classList.add("why__icon_animation");
			});
		}
		if (isVisible(document.querySelector(".sertificate")) && flagReview){
			flagReview = false;
			var allIcon = document.querySelectorAll(".review__item.select-center");

			[].forEach.call( allIcon, function (item) {
				item.classList.add("select-center_animation");
			});
		}
		if (isVisible(document.querySelector(".how-use")) && flagHowUse){
			flagHowUse = false;
			var allIcon = document.querySelectorAll(".how-use__item.select-center");

			[].forEach.call( allIcon, function (item) {
				item.classList.add("select-center_animation");
			});

			var addviceEl = document.querySelector(".advice");

			addviceEl.classList.add("advice_animation");
		}
	});

});

function isVisible(el) {
	var docViewTop = window.scrollY;
	//var elHeight = el.offsetHeight / 4;
	var elTop = offsetPosition(el);
	return (docViewTop > elTop);
}

function offsetPosition(element) {
    var offsetTop = 0;
    do {
        offsetTop  += element.offsetTop;
    } while (element = element.offsetParent);
    return offsetTop;
}
