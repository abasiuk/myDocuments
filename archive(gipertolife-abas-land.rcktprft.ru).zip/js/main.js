$(document).ready(function () {
	$(".more__btn").on("click", function (e) {
		e.preventDefault();
		$(this).parent().find(".min-text").toggleClass("full-text");
		$(this).toggleClass("more__btn_animate");
		if($(this).hasClass("more__btn_animate")){
			$(this).text("-");
		}else{
			$(this).text("+");
		}
	});
	/*composition*/
	$('.ev-composition__item').click(function () {
	    $(this).siblings().removeClass("ev-composition__item-full_height");
	    $(this).toggleClass("ev-composition__item-full_height");
	});

	/*slider operation*/
	$('.operation-block').slick({
	  dots: true,
	  infinite: true,
	  items: 1,
	  arrows: false,
	  speed: 500,
	  fade: true,
	  cssEase: 'linear'
	});
	$(".operation-block").prepend("<div class='operation__before'></div>");
	$(".operation-block").append("<div class='operation__after'></div>");
	var beforeImage = $(this).find('[data-slick-index="' + ($('.operation-block').slick("getSlick").slideCount - 1) + '"] img').attr("src");
	  	$(this).find(".operation__before").css("background-image", "url(" + beforeImage + ")");
	var	afterImage = $(this).find('[data-slick-index="1"] img').attr("src");
		$(this).find(".operation__after").css("background-image", "url(" + afterImage + ")");

	$('.operation-block').on('beforeChange', function(event, slick, currentSlide, nextSlide){
	  if (nextSlide - 1 != -1){
	  	beforeImage = $(this).find('[data-slick-index="' + currentSlide + '"] img').attr("src");
	  	$(this).find(".operation__before").css("background-image", "url(" + beforeImage + ")");
	  }else{
	  	beforeImage = $(this).find('[data-slick-index="' + (slick.slideCount - 1) + '"] img').attr("src");
	  	$(this).find(".operation__before").css("background-image", "url(" + beforeImage + ")");
	  }
	  if (nextSlide + 1 != slick.slideCount){
		afterImage = $(this).find('[data-slick-index="' + (nextSlide + 1) + '"] img').attr("src");
		$(this).find(".operation__after").css("background-image", "url(" + afterImage + ")");
	  }else{
		afterImage = $(this).find('[data-slick-index="0"] img').attr("src");
		$(this).find(".operation__after").css("background-image", "url(" + afterImage + ")");
		}
	});

	/*slider doctor*/
	$('.experts-block').slick({
	  infinite: false,
	  slidesToShow: 4,
	  arrows: false,
	  responsive:[{
	  	breakpoint: 1200,
	  	settings:{
	  		slidesToShow: 3,
	  		dots: true
	  	}
	  },{
	  	breakpoint: 991,
	  	settings:{
	  		slidesToShow: 2,
	  		dots: true
	  	}
	  },{
	  	breakpoint: 768,
	  	settings:{
	  		slidesToShow: 1,
	  		dots: true
	  	}
	  }],
	});

	/*add review*/
	$('#add-btn').on('click', function () {
	  	if ($('.add-review__field').val().trim().length > 15){
	  	$('.add-review__field').hide(300);
	  	$(this).hide(300);
	  	$('.add-review__result').text('Спасибо за отклик, ваш отзыв на модерации.');
	  	$('.add-review__result').css('marginTop', '75px');
	  }else{
	  	$('.add-review__result').text('Введите, пожалуйста, корректный отзыв.');
	  }
	  });

	/*problems more*/
	$(".problems__more").on("click", function (e) {
		var title = $(".problems__title_main").text(),
			desc = $(".problems__desc_main").text(),
			text = $(".problems__full_main").text(),
			name = $(".problems__author_main").text(),
		 	image = $(".problems__pic_main").attr("src"),
		 	imageArr = image.split("-");
		 	imageBw = imageArr[0] + "-bw-" + imageArr[1];

		$(".problems__title_main").text($(this).parent().parent().find(".problems__title").text());
		$(".problems__desc_main").text($(this).parent().parent().find(".problems__desc").text());
		$(".problems__pic_main").attr("src", $(this).parent().parent().find(".problems__pic_light").attr("src"));
		$(".problems__full_main").text($(this).parent().find(".problems__full").text());
		$(".problems__author_main").text($(this).parent().find(".problems__author").text());

		$(this).parent().parent().find(".problems__title").text(title);
		$(this).parent().parent().find(".problems__desc").text(desc);
		$(this).parent().parent().find(".problems__pic_light").attr("src", image);
		$(this).parent().parent().find(".problems__pic_bw").attr("src", imageBw);
		$(this).parent().find(".problems__full").text(text);
		$(this).parent().find(".problems__author").text(name);
	});

	/*add new dead*/
	var f = $('#dead-timer');
	var one = false;
	var corpses = 29;
	if(!localStorage["kills"]){
		localStorage["kills"] = corpses;
	}else{
		corpses = localStorage["kills"];
		$("#dead__first").text(String(corpses).split("")[0]);
		$("#dead__second").text(String(corpses).split("")[1]);
	}
	var timerId;
	$(window).scroll(function() {
		var w = $(this);
		if (w.scrollTop() > (f.offset().top - w.height())) {
			if (!one){
				one = true;
				addKill();
				timerId = setInterval(addKill, 5000);
			}
		} else {
			if(one){
				one = false;
				clearInterval(timerId);
			}
		}
	});
	function addKill() {
		var a = localStorage["kills"];
		a++;
		if(a < 99){
			localStorage["kills"] = a;
			$("#dead__first").text(String(a).split("")[0]);
			$("#dead__second").text(String(a).split("")[1]);
		}else{
			a = 29;
			localStorage["kills"] = a;
			$("#dead__first").text(String(a).split("")[0]);
			$("#dead__second").text(String(a).split("")[1]);
		}
	}

	/*diagram*/
	var diagram = $("#run-diagram");
	var onScreen = false;
	$(window).scroll(function() {
		var w = $(this);
		if (w.scrollTop() > (diagram.offset().top - w.height())) {
			if (!onScreen){
				onScreen = true;
				$(".diagram").addClass("diagram__anim");
			}
		} else {
			if(onScreen){
				onScreen = false;
			}
		}
	});
});