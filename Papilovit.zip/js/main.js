window.addEventListener("DOMContentLoaded", function() {
	var allbtn = document.querySelectorAll(".more-btn");
	[].forEach.call(allbtn, function(item) {
		item.addEventListener('click', function() {
			if (!item.parentNode.querySelector(".review__desc").classList.contains("review__desc_full")) {
				item.parentNode.querySelector(".review__desc").classList.add("review__desc_full");
				item.innerHTML = "-";
			} else {
				item.parentNode.querySelector(".review__desc").classList.remove("review__desc_full");
				item.innerHTML = "+";
			}
		});
	});
	/*slider review*/
	$('.review-block').slick({
		dots: true,
		infinite: true,
		items: 1,
		arrows: true,
		speed: 500,
		variableWidth: true,
		responsive: [{
			breakpoint: 1040,
			settings: {
				arrows: false,
			}
		}]
	});
	var reviewBefore = $(".review-block").find('[data-slick-index="' + ($('.review-block').slick("getSlick").slideCount - 1) + '"] .review__photo').clone()[0];
	var reviewAfter = $(".review-block").find('[data-slick-index="1"] .review__photo').clone()[0];
	updatePretest(reviewBefore);
	updatePretest(reviewAfter);
	$(".review__wrap").prepend(reviewBefore);
	$(".review__wrap").append("<div class='review__counter'><span id='review__current'>1</span>/<span id='review__count'>3</span></div>");
	$(".review__wrap").append(reviewAfter);
	$("#review__count").text($(".review-block").slick("getSlick").slideCount);
	$('.review-block').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
		if (nextSlide - 1 != -1) {
			beforeImage1 = $(this).find('[data-slick-index="' + (nextSlide - 1) + '"] .review__img_before img').attr("src");
			$(this).parent().find(".review__photo_slider:first-of-type .review__img_before img").attr("src", beforeImage1);
			beforeImage2 = $(this).find('[data-slick-index="' + (nextSlide - 1) + '"] .review__img_after img').attr("src");
			$(this).parent().find(".review__photo_slider:first-of-type .review__img_after img").attr("src", beforeImage2);
		} else {
			beforeImage1 = $(this).find('[data-slick-index="' + (slick.slideCount - 1) + '"] .review__img_before img').attr("src");
			$(this).parent().find(".review__photo_slider:first-of-type .review__img_before img").attr("src", beforeImage1);
			beforeImage2 = $(this).find('[data-slick-index="' + (slick.slideCount - 1) + '"] .review__img_after img').attr("src");
			$(this).parent().find(".review__photo_slider:first-of-type .review__img_after img").attr("src", beforeImage2);
		}
		if (nextSlide + 1 != slick.slideCount) {
			afterImage1 = $(this).find('[data-slick-index="' + (nextSlide + 1) + '"] .review__img_before img').attr("src");
			$(this).parent().find(".review__photo_slider:last-of-type .review__img_before img").attr("src", afterImage1);
			afterImage2 = $(this).find('[data-slick-index="' + (nextSlide + 1) + '"] .review__img_after img').attr("src");
			$(this).parent().find(".review__photo_slider:last-of-type .review__img_after img").attr("src", afterImage2);
		} else {
			afterImage1 = $(this).find('[data-slick-index="0"] .review__img_before img').attr("src");
			$(this).parent().find(".review__photo_slider:last-of-type .review__img_before img").attr("src", afterImage1);
			afterImage2 = $(this).find('[data-slick-index="0"] .review__img_after img').attr("src");
			$(this).parent().find(".review__photo_slider:last-of-type .review__img_after img").attr("src", afterImage2);
		}
		$("#review__current").text(nextSlide + 1);
	});
	$(".review__photo_slider:first-of-type").on("click", function() {
		$(".review-block").slick("slickPrev");
	});
	$(".review__photo_slider:last-of-type").on("click", function() {
		$(".review-block").slick("slickNext");
	});
	$(".review-block").on('beforeChange', function (event, slick, currentSlide, nextSlide) {
		$(".review__desc").removeClass("review__desc_full");
		$(".review-block .more-btn").text("+");
	});
	/* table slider - active for < 1200 */
	$('.table__slider').slick({
		dots: false,
		infinite: false,
		slidesToShow: 4,
		arrows: true,
		speed: 500,
		responsive: [{
			breakpoint: 1200,
			settings: {
				arrows: true,
				slidesToShow: 3
			}
		}, {
			breakpoint: 1025,
			settings: {
				arrows: true,
				slidesToShow: 2
			}
		}, {
			breakpoint: 769,
			settings: {
				arrows: true,
				slidesToShow: 1
			}
		}, ]
	});
	/* menu */
	$("#toggle-mnu").on('click', function(e) {
		e.preventDefault();
		$(this).toggleClass("on");
		$(this).parent().toggleClass('navbar_hide');
	});

	/* calculating all section */
	var allSect = $("main > section").length + 1;
	$(".sec-counter__all").text(allSect);

	/* acotiation arrays classes for animation */

	var animForSect2 = {
		".expert__profile": "expert__profile_arrow"
	};
	var animForSect4 = {
		".order-data__input": "order-data__input_anim",
		".price__old": "price__old_anim",
		".price__new": "price__new_anim"
	};
	var animForMainSect={
		".order-data__input": "order-data__input_anim",
		".price__old": "price__old_anim",
		".price__new": "price__new_anim"
	};
	addAnimForSection(".expert", animForSect2);
	addAnimForSection(".order-line", animForSect4);
	addAnimForSection(".main-head_last", animForMainSect);

	/* add data-item */
	$("body > header:first-of-type").attr("data-item", 1);
	changeSection("body > header:first-of-type", allSect);

	$("main > section").each(function (i, el) {
		$(el).attr("data-item", i + 2);
		changeSection(el, allSect);
	});

	$("a.menu__link, a.anchor__link").on("click", function (e) {
		e.preventDefault();
		var scroll_el = $(this).attr('href');
        if ($(scroll_el).length != 0) {
	    	$('html, body').animate({ scrollTop: $(scroll_el).offset().top }, 500);
        }
	    return false;
	});

	var flagPhoneResizeBool = true;
	var flagDesctopResizeBool = true;

	$(window).on('resize load', function () {
		if ($(this).width() < 768 && flagPhoneResizeBool){
			$("a.menu__link, a.anchor__link").off('click');
			$("a.menu__link, a.anchor__link").on('click', function (e) {
				e.preventDefault();
				var scroll_el = $(this).attr('href');
		        if ($(scroll_el).length != 0) {
			    	$('html, body').animate({ scrollTop: $(scroll_el).offset().top }, 500);
			    	$('#toggle-mnu').removeClass('on');
			    	$('#toggle-mnu').parent().addClass('navbar_hide');
		        }
			    return false;
			});
			flagPhoneResizeBool = false;
			flagDesctopResizeBool = true;
		}else if ($(this).width() >= 768 && flagDesctopResizeBool){
			$("a.menu__link, a.anchor__link").off('click');
			$("a.menu__link, a.anchor__link").on('click', function (e) {
				e.preventDefault();
				var scroll_el = $(this).attr('href');
		        if ($(scroll_el).length != 0) {
			    	$('html, body').animate({ scrollTop: $(scroll_el).offset().top }, 500);
		        }
			    return false;
			});
			flagPhoneResizeBool = true;
			flagDesctopResizeBool = false;
		}
	});

});

function updatePretest(el) {
	$(el).addClass("review__photo_slider")
	$(el).find(".review__label").remove();
	$(el).find(".review__pic").addClass("review__pic_slider");
}

function changeSection(el, count) {
	var target = $(el);
	var targetPos = target.offset().top;
	var winHeight = $(window).height();
	var scrollToElem = targetPos - winHeight;
	$(window).scroll(function(){
	  var winScrollTop = $(this).scrollTop();
	  if(winScrollTop > scrollToElem){
	    $(".sec-counter__current").text($(el).attr("data-item"));
	    diagramChange($(el).attr("data-item"), count);
	  }
	});
}

function diagramChange(current, all) {
	var oneSector = 360 / all;
	var currentSector = oneSector * current;

	if (currentSector <= 180){
		$(".sec-counter__right").css("transform", "rotate(" + currentSector + "deg)");
		$(".sec-counter__left").removeClass("sec-counter__left_full");
		$(".sec-counter__right").removeClass("sec-counter__right_full");
		$(".sec-counter-block").removeClass("sec-counter-block_full");
	}else{
		$(".sec-counter__right").css("transform", "rotate(" + ((180 - currentSector) * -1) + "deg)");
		$(".sec-counter__left").addClass("sec-counter__left_full");
		$(".sec-counter__right").addClass("sec-counter__right_full");
		$(".sec-counter-block").addClass("sec-counter-block_full");
	}
}

/* This is bad code, you can not write that */

function addAnimForSection(el, arr) {
	var target = $(el);
	var targetPos = target.offset().top;
	var winHeight = $(window).height();
	var scrollToElem = targetPos - winHeight;
	$(window).scroll(function(){
	  var winScrollTop = $(this).scrollTop();
	  var flag = true;
	  if(winScrollTop > scrollToElem){
	  	if (flag){
		  	for(var i = 0; i <= Object.keys(arr).length; i++){
		  		var key = Object.keys(arr)[i];
		  		$(el + " " + key).addClass(arr[key]);
		  	}
		  	flag = false;
	  	}
	  }
	});
}