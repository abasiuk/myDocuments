$(document).ready(function(){
	/*sliders*/
	  $('.review-block').slick({
		  slidesToShow: 3,
		  dots: true,
		  slidesToScroll: 1,
		  autoplay: false,
		  autoplaySpeed: 4000,
		  responsive: [{
			  breakpoint: 991,
			  settings: {
			    slidesToShow: 2,
			    arrows:false,
			  }
		  	},
		  	{
			  breakpoint: 768,
			  settings: {
			    slidesToShow: 1,
			    arrows: false,
			  },
			}
		  ]
		});
	  $('.kamasutra-block').slick({
		  slidesToShow: 3,
		  slidesToScroll: 1,
		  autoplay: false,
		  autoplaySpeed: 4000,
		  centerMode: true,
  		  centerPadding: '0',
  		  responsive: [{
			  breakpoint: 991,
			  settings: {
			    slidesToShow: 2,
			    arrows: false,
			  }
		  	},
		  	{
			  breakpoint: 768,
			  settings: {
			    slidesToShow: 1,
			    arrows: false,
			  },
			}
			]
		});
	  $('.solution-slider').slick({
		  slidesToShow: 3,
		  slidesToScroll: 1,
		  autoplay: false,
		  autoplaySpeed: 4000,
		  responsive: [{
			  breakpoint: 991,
			  settings: {
			    slidesToShow: 2,
			    arrows: false,
			  },
			},
			{
			  breakpoint: 768,
			  settings: {
			    slidesToShow: 1,
			    arrows: false,
			  },
			}]
		});
	/*custom scrool*/
		$("#doctor-scroll").niceScroll();
	/*more btn*/
	  var textReview = $('.review-block__text');
	  for (var i = 0; i < textReview.length; i++ ){
	  	if (textReview.eq(i).height() > 210){
	  		textReview.eq(i).parent().append('<a href="" class="review-block__more more">+</a>');
	  	}
	  	textReview.eq(i).height(210);
	  }
	  $('.review-block__more').on('click', function (e) {
	  	e.preventDefault();
	  	$(this).parent().toggleClass('review-block__main_shadow');
	  	var thisText = $(this).parent().find('.review-block__text');
	  	thisText.toggleClass('review-block__text_full');
	  	if (thisText.hasClass('review-block__text_full'))
	  		$(this).text('-');
	  	else
	  		$(this).text('+');
	  });

	  $('.usefulness__list .usefulness__full-btn, .usefulness__list .usefulness__name').on('click', function (e) {
	  	e.preventDefault();
	  	var thisText = $(this).parent().find('.usefulness__desc');
	  	thisText.animate({height: "toggle", paddingTop: "toggle"}, 300, function () {
	  		// body...
	  	});
	  	if (!$(this).hasClass('.usefulness__name')) {
	  		$(this).toggleClass('usefulness__full-btn_animate');
		}
	  });

	  $('.doctor__list .usefulness__full-btn, .doctor__list .doctor__title').on('click', function (e) {
	  	e.preventDefault();
	  	var thisTextFirst = $(this).parent().find('.doctor__desc:first');
	  	thisTextFirst.toggleClass('doctor__desc_first');
	  	var thisTextAll = $(this).parent().find('.doctor__desc:last');
	  	thisTextAll.toggleClass('doctor__desc_last');
	  	if (!$(this).hasClass('doctor__title')){
	  		$(this).toggleClass('usefulness__full-btn_animate');
	  	}
	  });
	  /*add comment*/
	  $('#addComment').on('click', function () {
	  	if ($('#review-textarea').val().trim().length > 15){
	  	$('#review-textarea').hide(300);
	  	$(this).hide(300);
	  	$('.text-review__message').text('Спасибо за отклик, ваш отзыв на модерации.');
	  	$('.text-review__message').css('marginTop', '75px');
	  }else{
	  	$('.text-review__message').text('Введите, пожалуйста, корректный отзыв.');
	  }
	  });
	  /*composition*/
	  
		var evSvgArray = $('.ev-composition__svg'),
		    evItemsArray = $('.ev-composition__item-description'),
		    evSvgActive='ev-composition__svg_active',
		    evRoundShow='ev-composition__center_round_show',
		    evBufferText='',
		    evRound='.ev-composition__center_round',
		    evItemFullHeight='ev-composition__item-full_height';


		$('path').hover(function () {
		    var parentSvg = $(this).parents('.ev-composition__svg'),
		        evIndexSvg = evSvgArray.index(parentSvg);

		    parentSvg.siblings('.ev-composition__svg').removeClass(evSvgActive);
		    $(evRound).html($(evItemsArray[evIndexSvg]).html()).removeClass(evRoundShow);
		    evBufferText=$(evItemsArray[evIndexSvg]).html();

		    if (parentSvg.hasClass(evSvgActive)) {
		        parentSvg.removeClass(evSvgActive);
		        $(evRound).html('').addClass(evRoundShow);
		        evBufferText='';
		    }
		    else {
		        parentSvg.addClass(evSvgActive);
		    }
		});

		$('.ev-composition__item').click(function(){
		    $(this).siblings().removeClass(evItemFullHeight);
		    $(this).toggleClass(evItemFullHeight);
		});

		$(window).on('resize',windowSize);

		function windowSize(){
		    if ($(window).width() <= '800'){
		        $(evRound).html('').addClass(evRoundShow);
		    }
		    else {
		        if(evBufferText!==''){
		            $(evRound).html(evBufferText).removeClass(evRoundShow);
		        }
		    }
		}


});