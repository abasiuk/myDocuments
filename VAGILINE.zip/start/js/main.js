$(document).ready(function () {
	$(".more-btn").on("click", function (e) {
		e.preventDefault();
		$(this).parent().find(".review__text").toggleClass("full-text");
		$(this).toggleClass("more-btn_animate");
	});
});