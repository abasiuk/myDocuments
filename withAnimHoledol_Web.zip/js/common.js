$(document).ready(function() {
	$('.owl-carousel').owlCarousel({
                loop:true, //Зацикливаем слайдер
                nav:true, //Вкл навигацию
                navText: false,
                autoplay:true, //Автозапуск слайдера
                smartSpeed:3500, //Время движения слайда
                autoplayTimeout:6000, //Время смены слайда
                items: 1
    });
    function timer(){
    curr_time = new Date();
    curr_hour = curr_time.getHours();
    curr_min = curr_time.getMinutes();
    curr_sec = curr_time.getSeconds();
    hour = 23-curr_hour;
    min = 60-curr_min;
    sec = 60 - curr_sec;
    if(hour<10){
        hour = "0"+hour;
    }
    if(min<10){
        min = "0"+min;
    }
    if(sec<10){
        sec = "0"+sec;
    }
    if(hour == 24){
        hour = "00";
    }
    if(min == 60){
        min = "00";
    }
    if(sec == 60){
        sec = "00";
    }
    hour1 = hour.toString().charAt(0);
    hour2 = hour.toString().charAt(1);
    min1 = min.toString().charAt(0);
    min2 = min.toString().charAt(1);
    sec1 = sec.toString().charAt(0);
    sec2 = sec.toString().charAt(1);
    $(".hour1").html(hour1);
    $(".hour2").html(hour2);
    $(".min1").html(min1);
    $(".min2").html(min2);
    $(".sec1").html(sec1);
    $(".sec2").html(sec2);
	}
	timer();
	setInterval(function(){timer()},1000);
});